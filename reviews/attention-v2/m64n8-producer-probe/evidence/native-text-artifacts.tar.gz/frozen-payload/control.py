import triton
import triton.language as tl
LOG2E = tl.constexpr(1.4426950408889634)

@triton.jit
def _norm_rope(x_ptr, offs_d, pos, theta, eps, ROPE: tl.constexpr, D: tl.constexpr, mask):
    """RMSNorm (no weight) then interleaved RoPE of rows x[..., D] (fp32).
    x_ptr: [R, 1] row base pointers; pos: [R, 1] positions; mask: [R, 1]."""
    x = tl.load(x_ptr + offs_d[None, :], mask=mask, other=0.0).to(tl.float32)
    inv = tl.rsqrt(tl.sum(x * x, 1) / D + eps)[:, None]
    x = x * inv
    if ROPE:
        partner = tl.load(x_ptr + (offs_d ^ 1)[None, :], mask=mask, other=0.0).to(tl.float32) * inv
        i = (offs_d // 2).to(tl.float32)
        inv_freq = tl.exp2(-(2.0 * i / D) * tl.log2(theta))
        ang = pos.to(tl.float32) * inv_freq[None, :]
        sign = tl.where((offs_d % 2) == 0, -1.0, 1.0)[None, :]
        x = x * tl.cos(ang) + sign * partner * tl.sin(ang)
    return x


@triton.jit
def _fused(qkv_ptr, seq_ptr, pt_ptr, loc_ptr, kc_ptr, vc_ptr, ks_ptr, vs_ptr,
           o_ptr, m_ptr, l_ptr, ticket_ptr, out_ptr,
           theta, eps, qk_factor, sm_scale, window, page, stride_tok, stride_pt,
           L: tl.constexpr, G: tl.constexpr, HQ: tl.constexpr, HKV: tl.constexpr,
           D: tl.constexpr, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_L: tl.constexpr,
           SPLITS: tl.constexpr, ROPE: tl.constexpr, WINDOWED: tl.constexpr,
           DOT: tl.constexpr, QK_DOT: tl.constexpr, CHUNK_SIZE: tl.constexpr, SEPARATE_MERGE: tl.constexpr,
           PAGE_LOOKAHEAD: tl.constexpr):
    b = tl.program_id(0)
    kvh = tl.program_id(1)
    split = tl.program_id(2)

    seq = tl.load(seq_ptr + b).to(tl.int64)
    # Query rows r = j * G + g  (block token j, query head kvh*G + g).
    offs_m = tl.arange(0, BLOCK_M)
    row_ok = offs_m < L * G
    j = tl.where(row_ok, offs_m // G, 0)
    g = offs_m % G
    qpos = seq + j
    offs_d = tl.arange(0, D)
    tok = (b * L + j).to(tl.int64)
    q_rows = qkv_ptr + tok[:, None] * stride_tok + ((kvh * G + g) * D)[:, None]
    q = _norm_rope(q_rows, offs_d, qpos[:, None], theta, eps, ROPE, D, row_ok[:, None])
    # FP8 query encoding follows the official scale placement: round unscaled Q.
    # Parent BF16(factor*Q) becomes E4M3(BF16(Q)); this changes rounding.
    # Factor is applied exactly once in qk_scale, never inside this FP8 cast.
    q = q.to(tl.bfloat16).to(tl.float8e4nv).to(QK_DOT)
    ks = tl.load(ks_ptr)
    vs = tl.load(vs_ptr)
    qk_scale = (sm_scale * qk_factor) * ks * LOG2E

    # Cached keys [lo, seq); new block keys [seq, seq + L).
    if WINDOWED:
        lo = tl.maximum(seq - window + 1, 0)   # earliest key the first block row sees
    else:
        lo = seq * 0
    lo = tl.minimum(lo, seq)
    span = seq - lo
    if CHUNK_SIZE:
        s_lo = split * CHUNK_SIZE
        s_hi = tl.minimum(s_lo + CHUNK_SIZE, seq)
    else:
        per = ((span + SPLITS - 1) // SPLITS + BLOCK_N - 1) // BLOCK_N * BLOCK_N
        s_lo = lo + split * per
        s_hi = tl.minimum(s_lo + per, seq)

    m_i = tl.full([BLOCK_M], float("-inf"), tl.float32)
    l_i = tl.zeros([BLOCK_M], tl.float32)
    acc = tl.zeros([BLOCK_M, D], tl.float32)
    offs_n = tl.arange(0, BLOCK_N)
    if PAGE_LOOKAHEAD:
        first_t = s_lo + offs_n
        first_ok = first_t < s_hi
        first_pg = tl.load(pt_ptr + b * stride_pt + first_t // page,
                           mask=first_ok, other=0).to(tl.int64)
        first_pg = tl.maximum(first_pg, 0)
        row_current = first_pg * page + first_t % page
    for start in range(s_lo, s_hi, BLOCK_N):
        t = start + offs_n
        t_ok = t < s_hi
        if PAGE_LOOKAHEAD:
            row = row_current
        else:
            pg = tl.load(pt_ptr + b * stride_pt + t // page, mask=t_ok, other=0).to(tl.int64)
            pg = tl.maximum(pg, 0)
            row = pg * page + t % page
        kv_off = row[:, None] * (HKV * D) + kvh * D + offs_d[None, :]
        k = tl.load(kc_ptr + kv_off, mask=t_ok[:, None], other=0.0).to(QK_DOT)
        if PAGE_LOOKAHEAD:
            # Historical addresses only: no K/V payload prefetch or new-token reads.
            next_t = t + BLOCK_N
            next_ok = next_t < s_hi
            next_pg = tl.load(pt_ptr + b * stride_pt + next_t // page,
                              mask=next_ok, other=0)
        s = tl.dot(q, tl.trans(k), out_dtype=tl.float32, max_num_imprecise_acc=0) * qk_scale  # log2 domain
        vis = t_ok[None, :]
        if WINDOWED:
            vis = vis & (t[None, :] > qpos[:, None] - window)
        s = tl.where(vis, s, float("-inf"))
        m_new = tl.maximum(m_i, tl.max(s, 1))
        m_safe = tl.where(m_new == float("-inf"), 0.0, m_new)
        alpha = tl.exp2(m_i - m_safe)
        p = tl.exp2(s - m_safe[:, None])
        l_i = l_i * alpha + tl.sum(p, 1)
        v = tl.load(vc_ptr + kv_off, mask=t_ok[:, None], other=0.0).to(DOT)
        acc = acc * alpha[:, None] + tl.dot(p.to(tl.bfloat16).to(DOT), v)
        m_i = m_new
        if PAGE_LOOKAHEAD:
            # First use of next_pg is after the current QK/PV work in source.
            next_pg64 = tl.maximum(next_pg.to(tl.int64), 0)
            row_next = next_pg64 * page + next_t % page
            row_current = row_next

    if split == SPLITS - 1:
        # The block's own L tokens: compute, quantize, store, attend.
        offs_l = tl.arange(0, BLOCK_L)
        l_ok = offs_l < L
        ntok = (b * L + tl.where(l_ok, offs_l, 0)).to(tl.int64)
        npos = seq + offs_l
        k_rows = qkv_ptr + ntok[:, None] * stride_tok + (HQ * D + kvh * D)
        kn = _norm_rope(k_rows, offs_d, npos[:, None], theta, eps, ROPE, D, l_ok[:, None])
        vn = tl.load(qkv_ptr + ntok[:, None] * stride_tok + ((HQ + HKV) * D + kvh * D)
                     + offs_d[None, :], mask=l_ok[:, None], other=0.0).to(tl.float32)
        kq = (kn / ks).to(kc_ptr.dtype.element_ty)
        vq = (vn / vs).to(vc_ptr.dtype.element_ty)
        loc = tl.load(loc_ptr + ntok, mask=l_ok, other=0)
        dst = loc[:, None] * (HKV * D) + kvh * D + offs_d[None, :]
        tl.store(kc_ptr + dst, kq, mask=l_ok[:, None])
        tl.store(vc_ptr + dst, vq, mask=l_ok[:, None])
        s = tl.dot(q, tl.trans(kq.to(QK_DOT)), out_dtype=tl.float32, max_num_imprecise_acc=0) * qk_scale
        vis = l_ok[None, :] & (npos[None, :] <= qpos[:, None])
        s = tl.where(vis, s, float("-inf"))
        m_new = tl.maximum(m_i, tl.max(s, 1))
        m_safe = tl.where(m_new == float("-inf"), 0.0, m_new)
        alpha = tl.exp2(m_i - m_safe)
        p = tl.exp2(s - m_safe[:, None])
        l_i = l_i * alpha + tl.sum(p, 1)
        acc = acc * alpha[:, None] + tl.dot(p.to(tl.bfloat16).to(DOT), vq.to(tl.float32).to(DOT))
        m_i = m_new

    head = kvh * G + g
    out_off = tok[:, None] * (HQ * D) + head[:, None] * D + offs_d[None, :]
    gate_off = tok[:, None] * stride_tok + ((HQ + 2 * HKV) * D) + head[:, None] * D + offs_d[None, :]
    if SPLITS == 1:
        a = acc * vs / l_i[:, None]
        a = a * tl.rsqrt(tl.sum(a * a, 1) / D + eps)[:, None]
        gate = tl.load(qkv_ptr + gate_off, mask=row_ok[:, None], other=0.0).to(tl.float32)
        tl.store(out_ptr + out_off, (a * tl.sigmoid(gate)).to(tl.bfloat16), mask=row_ok[:, None])
    else:
        # Partials [B, HKV, SPLITS, BLOCK_M, (D)].
        pbase = ((b * HKV + kvh) * SPLITS + split) * BLOCK_M + offs_m
        tl.store(o_ptr + pbase[:, None] * D + offs_d[None, :], acc)
        tl.store(m_ptr + pbase, m_i)
        tl.store(l_ptr + pbase, l_i)
        if not SEPARATE_MERGE:
            tl.debug_barrier()  # every warp's partial stores precede the ticket (release below)
            tk = ticket_ptr + b * HKV + kvh
            prev = tl.atomic_add(tk, 1, sem="acq_rel", scope="gpu")
            if prev == SPLITS - 1:
                m_t = tl.full([BLOCK_M], float("-inf"), tl.float32)
                l_t = tl.zeros([BLOCK_M], tl.float32)
                a = tl.zeros([BLOCK_M, D], tl.float32)
                for s_i in range(0, SPLITS):
                    qb = ((b * HKV + kvh) * SPLITS + s_i) * BLOCK_M + offs_m
                    m_s = tl.load(m_ptr + qb, cache_modifier=".cg")
                    l_s = tl.load(l_ptr + qb, cache_modifier=".cg")
                    o_s = tl.load(o_ptr + qb[:, None] * D + offs_d[None, :], cache_modifier=".cg")
                    m_n = tl.maximum(m_t, m_s)
                    m_z = tl.where(m_n == float("-inf"), 0.0, m_n)
                    w_t = tl.exp2(m_t - m_z)
                    w_s = tl.exp2(m_s - m_z)
                    l_t = l_t * w_t + l_s * w_s
                    a = a * w_t[:, None] + o_s * w_s[:, None]
                    m_t = m_n
                a = a * vs / l_t[:, None]
                a = a * tl.rsqrt(tl.sum(a * a, 1) / D + eps)[:, None]
                gate = tl.load(qkv_ptr + gate_off, mask=row_ok[:, None], other=0.0).to(tl.float32)
                tl.store(out_ptr + out_off, (a * tl.sigmoid(gate)).to(tl.bfloat16), mask=row_ok[:, None])
                tl.atomic_xchg(tk, 0, sem="relaxed", scope="gpu")


